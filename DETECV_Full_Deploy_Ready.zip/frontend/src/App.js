import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import LoginForm from './components/Auth/LoginForm';
import RegisterForm from './components/Auth/RegisterForm';
import PatientDashboard from './components/Patient/PatientDashboard';
import DiagnosisForm from './components/Diagnosis/DiagnosisForm';
import NotificationForm from './components/Notification/NotificationForm';

const App = () => {
  const [currentView, setCurrentView] = useState('landing');
  const [loggedIn, setLoggedIn] = useState(false);
  const [currentPatient, setCurrentPatient] = useState(null);

  const handleAccess = () => {
    setCurrentView('login');
  };

  const handleLoginSuccess = () => {
    setLoggedIn(true);
    setCurrentView('patientDashboard');
  };

  const handleRegisterSuccess = () => {
    setCurrentView('login');
  };

  const handleRegisterPatient = (patientData) => {
    setCurrentPatient(patientData);
    setCurrentView('diagnosis');
  };

  const handleCompleteDiagnosis = () => {
    setCurrentView('notification');
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setCurrentView('landing');
    setCurrentPatient(null);
  };

  const handleSearchPatient = (patient) => {
    setCurrentPatient(patient);
    setCurrentView('diagnosis');
  };

  const handleReturnToDashboard = () => {
    setCurrentView('patientDashboard');
  };

  const appStyle = {
    minHeight: '100vh'
  };

  const contentStyle = {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: '1rem',
    padding: '2rem',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
    margin: '2rem auto',
    maxWidth: '1400px',
    backdropFilter: 'blur(2px)',
    border: '1px solid rgba(255, 255, 255, 0.3)'
  };

  const navStyle = {
    backgroundColor: 'rgba(255, 255, 255, 0.97)',
    padding: '1rem 2rem',
    borderRadius: '0.5rem',
    boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '2rem'
  };

  const views = {
    landing: <LandingPage onAccess={handleAccess} />,
    login: (
      <div className="flex flex-col items-center">
        <LoginForm onLoginSuccess={handleLoginSuccess} />
        <button
          onClick={() => setCurrentView('register')}
          className="mt-6 px-6 py-2 bg-blue-100 hover:bg-blue-200 text-blue-800 font-medium rounded-lg"
        >
          ¿No tienes cuenta? Regístrate
        </button>
      </div>
    ),
    register: <RegisterForm onRegisterSuccess={handleRegisterSuccess} />,
    patientDashboard: (
      <PatientDashboard 
        onRegisterPatient={handleRegisterPatient} 
        onSearchPatient={handleSearchPatient}
      />
    ),
    diagnosis: (
      <DiagnosisForm 
        patient={currentPatient} 
        onComplete={handleCompleteDiagnosis}
        onBack={handleReturnToDashboard}
      />
    ),
    notification: (
      <NotificationForm 
        patient={currentPatient}
        onComplete={handleReturnToDashboard}
      />
    )
  };

  return (
    <div style={appStyle}>
      {currentView === 'landing' ? (
        views.landing
      ) : (
        <div className="container mx-auto px-4 py-8">
          {loggedIn && (
            <div style={navStyle}>
              <div className="flex items-center space-x-4">
                <h1 className="text-2xl font-bold text-red-700 flex items-center">
                  <span className="mr-2" style={{ fontSize: '28px' }}>❤️</span>
                  Sistema Det-ECG
                </h1>
                {currentView !== 'patientDashboard' && (
                  <button
                    onClick={handleReturnToDashboard}
                    className="px-4 py-2 bg-blue-100 hover:bg-blue-200 text-blue-800 rounded-lg"
                  >
                    Volver al Panel
                  </button>
                )}
              </div>
              <button
                onClick={handleLogout}
                className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg flex items-center"
              >
                <span className="mr-2">🚪</span>
                Cerrar Sesión
              </button>
            </div>
          )}
          <div style={contentStyle}>
            {views[currentView]}
          </div>
        </div>
      )}
    </div>
  );
};

export default App;

// DONE