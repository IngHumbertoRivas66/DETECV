import React, { useState } from 'react';

const LoginForm = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (email && password) {
      onLoginSuccess();
    } else {
      setError('Por favor ingrese email y contraseña');
    }
  };

  const formStyle = {
    maxWidth: '450px',
    margin: '0 auto',
    padding: '2.5rem',
    borderRadius: '1rem',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)'
  };

  return (
    <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center' }}>
      <div style={formStyle}>
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-red-700">
            Iniciar sesión
          </h2>
          <p className="mt-2 text-blue-800">Acceso para médicos cardiólogos</p>
        </div>
        <form className="space-y-6" onSubmit={handleSubmit}>
          {error && <div className="text-red-500 text-sm text-center">{error}</div>}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-blue-800 mb-1">
                Correo electrónico
              </label>
              <input
                type="email"
                required
                className="w-full px-4 py-3 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-blue-800 mb-1">
                Contraseña
              </label>
              <input
                type="password"
                required
                className="w-full px-4 py-3 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>
          <div>
            <button
              type="submit"
              className="w-full py-3 px-4 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
            >
              Ingresar al Sistema
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;

// DONE