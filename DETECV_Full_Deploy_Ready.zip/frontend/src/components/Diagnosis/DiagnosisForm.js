import React, { useState } from 'react';

const DiagnosisForm = ({ patient, onComplete, onBack }) => {
  const [diagnosis, setDiagnosis] = useState('');
  const [treatment, setTreatment] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 p-6 rounded-xl">
        <h2 className="text-2xl font-bold text-red-700 mb-2">Diagnóstico para {patient.fullId}</h2>
        <p className="text-blue-800">
          <span className="font-semibold">Paciente:</span> {patient.firstName} {patient.lastName}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-xl font-semibold text-blue-800 mb-4">Diagnóstico</h3>
          <textarea
            rows="4"
            required
            className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            value={diagnosis}
            onChange={(e) => setDiagnosis(e.target.value)}
            placeholder="Describa el diagnóstico del paciente..."
          />
        </div>

        <div className="bg-white p-6 rounded-xl shadow">
          <h3 className="text-xl font-semibold text-blue-800 mb-4">Tratamiento</h3>
          <textarea
            rows="6"
            required
            className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            value={treatment}
            onChange={(e) => setTreatment(e.target.value)}
            placeholder="Describa el tratamiento recomendado..."
          />
        </div>

        <div className="flex justify-between">
          <button
            type="button"
            onClick={onBack}
            className="px-6 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg"
          >
            Volver
          </button>
          <button
            type="submit"
            className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
          >
            Continuar a Notificación
          </button>
        </div>
      </form>
    </div>
  );
};

export default DiagnosisForm;