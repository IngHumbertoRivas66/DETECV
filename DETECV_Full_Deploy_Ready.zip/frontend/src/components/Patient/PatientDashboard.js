import React, { useState } from 'react';
import PatientForm from './PatientForm';
import PatientSearch from './PatientSearch';

const PatientDashboard = ({ onRegisterPatient, onSearchPatient }) => {
  const [activeTab, setActiveTab] = useState('register');

  return (
    <div className="space-y-8">
      <div className="flex border-b border-gray-200">
        <button
          className={`py-4 px-6 font-medium text-lg ${activeTab === 'register' ? 'text-red-600 border-b-2 border-red-600' : 'text-blue-800'}`}
          onClick={() => setActiveTab('register')}
        >
          Registrar Nuevo Paciente
        </button>
        <button
          className={`py-4 px-6 font-medium text-lg ${activeTab === 'search' ? 'text-red-600 border-b-2 border-red-600' : 'text-blue-800'}`}
          onClick={() => setActiveTab('search')}
        >
          Buscar Paciente Existente
        </button>
      </div>

      {activeTab === 'register' ? (
        <PatientForm onSubmit={onRegisterPatient} />
      ) : (
        <PatientSearch onSearch={onSearchPatient} />
      )}
    </div>
  );
};

export default PatientDashboard;