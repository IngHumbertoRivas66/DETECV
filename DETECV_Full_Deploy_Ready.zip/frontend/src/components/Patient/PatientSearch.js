import React, { useState } from 'react';

const PatientSearch = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('id');
  const [searchResults, setSearchResults] = useState([]);

  const handleSearch = (e) => {
    e.preventDefault();
    // Simulación de búsqueda - en una implementación real harías una petición a tu API
    const mockResults = [
      {
        id: 'V-12345678',
        name: 'Juan Pérez',
        age: 45,
        email: 'juan.perez@example.com',
        lastVisit: '2023-05-15'
      },
      {
        id: 'V-87654321',
        name: 'María González',
        age: 32,
        email: 'maria.gonzalez@example.com',
        lastVisit: '2023-06-20'
      }
    ];
    setSearchResults(mockResults);
    onSearch();
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 p-6 rounded-xl">
        <h3 className="text-xl font-semibold text-blue-800 mb-4">Buscar Paciente</h3>
        <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-blue-800 mb-1">Tipo de Búsqueda</label>
            <select
              value={searchType}
              onChange={(e) => setSearchType(e.target.value)}
              className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            >
              <option value="id">Por Cédula</option>
              <option value="name">Por Nombre</option>
              <option value="email">Por Email</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-blue-800 mb-1">Término de Búsqueda</label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder={searchType === 'id' ? 'Ej: V-12345678' : 'Buscar...'}
            />
          </div>
          <div className="self-end">
            <button
              type="submit"
              className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg"
            >
              Buscar
            </button>
          </div>
        </form>
      </div>

      {searchResults.length > 0 && (
        <div className="bg-white p-6 rounded-xl shadow">
          <h4 className="text-lg font-semibold text-blue-800 mb-4">Resultados de Búsqueda</h4>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-blue-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Cédula</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Nombre</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Edad</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Última Visita</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-blue-800 uppercase tracking-wider">Acciones</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {searchResults.map((patient) => (
                  <tr key={patient.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-800">{patient.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-800">{patient.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-800">{patient.age}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-800">{patient.lastVisit}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-800">
                      <button className="text-red-600 hover:text-red-800 mr-4">Ver</button>
                      <button className="text-red-600 hover:text-red-800">Editar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientSearch;

// DONE