import React, { useState } from 'react';

const PatientForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    idType: 'V',
    idNumber: '',
    age: '',
    phone: '',
    address: '',
    email: '',
    pathology: '',
    investigationType: []
  });

  const investigationOptions = [
    'Electrocardiograma',
    'Ecocardiograma',
    'Prueba de Esfuerzo',
    'Holter',
    'MAPA'
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleIdNumberChange = (e) => {
    const { value } = e.target;
    const cleanValue = value.replace(/^[VE]-/, '');
    setFormData(prev => ({ ...prev, idNumber: cleanValue }));
  };

  const handleInvestigationChange = (option) => {
    setFormData(prev => {
      const newInvestigation = [...prev.investigationType];
      if (newInvestigation.includes(option)) {
        return { ...prev, investigationType: newInvestigation.filter(item => item !== option) };
      } else {
        return { ...prev, investigationType: [...newInvestigation, option] };
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const fullPatientData = {
      ...formData,
      fullId: `${formData.idType}-${formData.idNumber}`,
      fullName: `${formData.firstName} ${formData.lastName}`
    };
    onSubmit(fullPatientData);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-red-700 mb-8 text-center">Registro de Paciente</h2>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Sección Información Personal */}
          <div className="bg-blue-50 p-6 rounded-xl">
            <h3 className="text-xl font-semibold text-blue-800 mb-4">Información Personal</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Nombres</label>
                <input
                  type="text"
                  name="firstName"
                  required
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.firstName}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Apellidos</label>
                <input
                  type="text"
                  name="lastName"
                  required
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.lastName}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Edad</label>
                <input
                  type="number"
                  name="age"
                  required
                  min="0"
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.age}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          {/* Sección Identificación */}
          <div className="bg-blue-50 p-6 rounded-xl">
            <h3 className="text-xl font-semibold text-blue-800 mb-4">Identificación</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-2">Tipo de Cédula</label>
                <div className="flex space-x-6">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="idType"
                      value="V"
                      checked={formData.idType === 'V'}
                      onChange={handleChange}
                      className="h-5 w-5 text-red-600 focus:ring-red-500 border-blue-300"
                    />
                    <span className="ml-2 text-blue-800">V- Venezolana</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="idType"
                      value="E"
                      checked={formData.idType === 'E'}
                      onChange={handleChange}
                      className="h-5 w-5 text-red-600 focus:ring-red-500 border-blue-300"
                    />
                    <span className="ml-2 text-blue-800">E- Extranjera</span>
                  </label>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Número de Cédula</label>
                <div className="flex rounded-lg shadow-sm">
                  <span className="inline-flex items-center px-4 rounded-l-lg border border-r-0 border-blue-300 bg-blue-100 text-blue-800">
                    {formData.idType}-
                  </span>
                  <input
                    type="text"
                    name="idNumber"
                    required
                    className="flex-1 block w-full px-4 py-2 rounded-r-lg border border-blue-300 focus:ring-2 focus:ring-red-500 focus:border-red-500"
                    value={formData.idNumber}
                    onChange={handleIdNumberChange}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Sección Contacto */}
          <div className="bg-blue-50 p-6 rounded-xl">
            <h3 className="text-xl font-semibold text-blue-800 mb-4">Contacto</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Teléfono</label>
                <input
                  type="tel"
                  name="phone"
                  required
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.phone}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Dirección</label>
                <input
                  type="text"
                  name="address"
                  required
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.address}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Correo Electrónico</label>
                <input
                  type="email"
                  name="email"
                  required
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          {/* Sección Médica */}
          <div className="bg-blue-50 p-6 rounded-xl">
            <h3 className="text-xl font-semibold text-blue-800 mb-4">Información Médica</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-1">Patología</label>
                <input
                  type="text"
                  name="pathology"
                  required
                  className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  value={formData.pathology}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blue-800 mb-2">Tipo de Investigación</label>
                <div className="grid grid-cols-1 gap-2">
                  {investigationOptions.map(option => (
                    <label key={option} className="inline-flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.investigationType.includes(option)}
                        onChange={() => handleInvestigationChange(option)}
                        className="h-5 w-5 text-red-600 focus:ring-red-500 border-blue-300 rounded"
                      />
                      <span className="ml-2 text-blue-800">{option}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center mt-8">
          <button
            type="submit"
            className="px-8 py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors"
          >
            Registrar Paciente
          </button>
        </div>
      </form>
    </div>
  );
};

export default PatientForm;

// DONE