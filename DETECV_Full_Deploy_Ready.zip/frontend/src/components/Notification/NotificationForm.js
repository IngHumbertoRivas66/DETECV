import React, { useState } from 'react';

const NotificationForm = ({ patient, onComplete }) => {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aquí iría la lógica para enviar la notificación
    alert(`Notificación programada para ${patient.fullName} en ${date} a las ${time}`);
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 p-6 rounded-xl">
        <h2 className="text-2xl font-bold text-red-700 mb-2">Programar Control para {patient.fullId}</h2>
        <p className="text-blue-800">
          <span className="font-semibold">Paciente:</span> {patient.firstName} {patient.lastName}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-blue-800 mb-1">Fecha del Control</label>
            <input
              type="date"
              required
              className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-blue-800 mb-1">Hora del Control</label>
            <input
              type="time"
              required
              className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              value={time}
              onChange={(e) => setTime(e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-blue-800 mb-1">Mensaje Adicional</label>
          <textarea
            rows="4"
            className="w-full px-4 py-2 border border-blue-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Instrucciones adicionales para el paciente..."
          />
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg"
          >
            Programar Control
          </button>
        </div>
      </form>
    </div>
  );
};

export default NotificationForm;

// DONE