
import React from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../../assets/Logotipo de la intefaz web.png';
import { ArrowRightCircle } from 'lucide-react';

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-white">
      <img src={logo} alt="Logo Detecv" className="w-1/2 max-w-md mb-10" />
      <button
        onClick={() => navigate('/login')}
        className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white text-lg font-semibold rounded-2xl shadow-md hover:bg-red-700 transition"
      >
        Acceder <ArrowRightCircle size={24} />
      </button>
    </div>
  );
};

export default LandingPage;
