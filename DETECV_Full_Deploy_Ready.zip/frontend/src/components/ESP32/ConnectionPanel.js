import React, { useState } from 'react';

const ConnectionPanel = () => {
  const [connectionType, setConnectionType] = useState('wifi');
  const [wifiCredentials, setWifiCredentials] = useState({
    ssid: '',
    password: ''
  });
  const [bluetoothStatus, setBluetoothStatus] = useState('disconnected');

  const handleWifiChange = (e) => {
    const { name, value } = e.target;
    setWifiCredentials(prev => ({ ...prev, [name]: value }));
  };

  const connectDevice = () => {
    // Lógica para conectar ESP32
    if (connectionType === 'wifi') {
      console.log('Conectando via WiFi:', wifiCredentials);
    } else {
      console.log('Conectando via Bluetooth');
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Conexión ESP32</h2>
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tipo de Conexión
          </label>
          <div className="flex space-x-4">
            <button
              type="button"
              className={`px-4 py-2 rounded-md ${connectionType === 'wifi' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700'}`}
              onClick={() => setConnectionType('wifi')}
            >
              WiFi
            </button>
            <button
              type="button"
              className={`px-4 py-2 rounded-md ${connectionType === 'bluetooth' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700'}`}
              onClick={() => setConnectionType('bluetooth')}
            >
              Bluetooth
            </button>
          </div>
        </div>

        {connectionType === 'wifi' ? (
          <div className="space-y-4">
            <div>
              <label htmlFor="ssid" className="block text-sm font-medium text-gray-700">
                Nombre de Red (SSID)
              </label>
              <input
                type="text"
                id="ssid"
                name="ssid"
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                value={wifiCredentials.ssid}
                onChange={handleWifiChange}
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Contraseña WiFi
              </label>
              <input
                type="password"
                id="password"
                name="password"
                required
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                value={wifiCredentials.password}
                onChange={handleWifiChange}
              />
            </div>
          </div>
        ) : (
          <div className="p-4 bg-gray-50 rounded-md">
            <p className="text-gray-700">Estado Bluetooth: {bluetoothStatus}</p>
            <button
              type="button"
              className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
              onClick={() => setBluetoothStatus(prev => prev === 'disconnected' ? 'connecting' : 'disconnected')}
            >
              {bluetoothStatus === 'disconnected' ? 'Conectar Dispositivo' : 'Desconectar'}
            </button>
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="button"
            className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            onClick={connectDevice}
          >
            {connectionType === 'wifi' ? 'Conectar via WiFi' : 'Buscar Dispositivo Bluetooth'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConnectionPanel;